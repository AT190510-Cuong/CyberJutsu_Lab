<ul>
  <li><a href="/">Hall of fame</a></li>
  <li><a href="/game.php">Game</a></li>
  <li><a href="/profile.php">Profile</a></li>
</ul>
